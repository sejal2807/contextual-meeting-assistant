from ..punctuation import TOKENIZER_SUFFIXES

_suffixes = TOKENIZER_SUFFIXES
