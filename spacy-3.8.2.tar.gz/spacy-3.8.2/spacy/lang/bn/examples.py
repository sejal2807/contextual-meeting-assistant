"""
Example sentences to test spaCy and its language models.

>>> from spacy.lang.bn.examples import sentences
>>> docs = nlp.pipe(sentences)
"""


sentences = ["তুই খুব ভালো", "আজ আমরা ডাক্তার দেখতে যাবো", "আমি জানি না "]
