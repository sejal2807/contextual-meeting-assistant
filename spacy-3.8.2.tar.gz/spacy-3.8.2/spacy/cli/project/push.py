from weasel.cli.push import *
